#include <stdio.h>

void test();

int main() {
  printf("Hello World!\n");
  test();
}

void test() { printf("test\n"); }
